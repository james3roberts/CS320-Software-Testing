package Contact;
import java.util.ArrayList;

public class ContactService {
	private ArrayList<Contact> contacts;
  	public ContactService(){
		contacts = new ArrayList<>();
}
	public boolean addContact(Contact contact){
		boolean contactAlready= false;
			for (Contact contactList:contacts){
			if (contactList.equals(contact)){
				contactAlready = true;
			}
		}
			if (!contactAlready){
				contacts.add(contact);
			return true;
			}
			else{
		return false;
		}
	}
	public boolean deleteContact(String string){
		for (Contact contactList:contacts){
			if (contactList.getContactId().equals(string)){
				contacts.remove(contactList);
			return true;
			}
			}
		return false;

	}
	
		public boolean updateContact(String contactId, String firstName, String lastName, String phoneNum, String address){
			for (Contact contactList:contacts){
				if (contactId == null || contactId.length()> 10){
 			throw new IllegalArgumentException("Invalid Contact ID");
 		}
 		if (firstName == null || firstName.length () >10){
 			throw new IllegalArgumentException("Invalid First Name");
 		}
 		if (lastName == null || lastName.length () > 10){
 			throw new IllegalArgumentException("Invalid Last Name");
 		}
 		if (phoneNum == null || phoneNum.length () >10 || phoneNum.length ()<10){
 			throw new IllegalArgumentException("Invalid Phone Number");
 		}
 		if (address == null || address.length () >30){
 			throw new IllegalArgumentException("Invalid Address");
 		} 

 	}

			return true;
}{

}
}