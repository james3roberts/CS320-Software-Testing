package test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import Contact.Contact;

class ContactService{
	@Test
	void testAdd(){
		ContactService contactService = new ContactService();
		Contact test1 = new Contact("Ironman", "Tony", "Stark","2129704133", "10880 Malibu Point, 90265");
		assertTrue(contactService.addContact(test1));
	}

	@Test
	void testDelete(){
		Assertions.assertThrows(IllegalArgumentException.class,()->{
		ContactService contactService = new ContactService();
		Contact test1 = new Contact("Ironman", "Tony", "Stark","2129704133", "10880 Malibu Point, 90265");
		Contact test2 = new Contact("Java 102111", "12345", "Java 102123", "98765","Java 124578");
		Contact test3 = new Contact("Java 102!@1", "12345789", "Java *0&123", "9821765","Java 1245%78");
		contactService.deleteContact(test1);
		contactService.deleteContact(test2);
		contactService.deleteContact(test3);
		assertTrue(contactService.deleteContact("Ironman"));
	});
		}

	@Test
	void testUpdate(){
		Assertions.assertThrows(IllegalArgumentException.class,()->{
		ContactService contactService = new ContactService();
		Contact test1 = new Contact("Ironman", "Tony", "Stark","2129704133", "10880 Malibu Point, 90265");
		Contact test2 = new Contact("Java 102111", "12345", "Java 102123", "98765","Java 124578");
		Contact test3 = new Contact("Java 102!@1", "12345789", "Java *0&123", "9821765","Java 1245%78");
		contactService.updateContact(test1);
		contactService.updateContact(test2);
		contactService.updateContact(test3);
		assertTrue(contactService.updateContact("Ironman"));
		});
		}

}