package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Contact.Contact;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact("Ironman", "Tony", "Stark","2129704133", "10880 Malibu Point, 90265");
		assertTrue(contact.getContactId().equals("Ironman"));
		assertTrue(contact.getFristName().equals("Tony"));
		assertTrue(contact.getLastName().equals ("Stark"));
		assertTrue(contact.getPhoneNum().equals("2129704133"));
		assertTrue(contact.getAddress().equals("10880 Malibu Point, 90265"));
	}
	
	
	
	@Test
	void testContactIdToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("Java 102111", "12345","Java 102123","98765","Java 124578");
		});
	}
	
	@Test
	void testContactNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact(null, "12345",null,"98765",null);
		});
	}
	
	@Test
	void testContactFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Java 102", "12345678912", "Java 103", "123456789110", "Java 104");
		});
	}
	
	@Test
	void testContactLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Java 102", "12345678912", "Java 103", "123456789110", "Java 104");
		});
	}
	@Test
	void testContactAddressLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("Colorado, Colorado Springs,987654", "12345","Java 102123","98765","Java 124578");
		});
	}
}

